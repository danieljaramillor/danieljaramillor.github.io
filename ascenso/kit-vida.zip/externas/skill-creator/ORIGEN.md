# Procedencia: skill-creator

Copia de la carpeta completa de una skill pública oficial, preparada el 25 de noviembre de 2026.

- Repositorio: https://github.com/anthropics/skills
- Commit fijado: `e4bb5d960d87126ff3b3a8af1a104b7db67560ba`
- Carpeta original: `skills/skill-creator`
- Fuente: https://github.com/anthropics/skills/tree/e4bb5d960d87126ff3b3a8af1a104b7db67560ba/skills/skill-creator
- SKILL.md original: https://raw.githubusercontent.com/anthropics/skills/e4bb5d960d87126ff3b3a8af1a104b7db67560ba/skills/skill-creator/SKILL.md
- Licencia: Apache-2.0. Se conserva `LICENSE.upstream` y cualquier licencia/aviso original dentro de la carpeta.
- Licencia original: https://github.com/anthropics/skills/blob/e4bb5d960d87126ff3b3a8af1a104b7db67560ba/skills/skill-creator/LICENSE.txt
- SHA-256 del archivo de origen descargado: `287d5d39770a929db26f35fd13833b53f1ac3db58b96c76602b3487f8f573e19`.

## Cambios de empaquetado

No se modificaron los archivos originales de esta skill.

Se añadieron este archivo de procedencia y los avisos de licencia de acompañamiento. Los avisos originales se conservan.

## Compatibilidad y comprobación

Conservar la carpeta completa y sus recursos. La ejecución depende de herramientas y permisos reales del asistente. Sus evaluaciones y comandos específicos de Claude deben adaptarse o declararse no disponibles en otros asistentes; no se ejecutaron.

Se comprobó que existe SKILL.md y se copiaron sus recursos. No se ejecutaron scripts upstream ni se instaló esta skill en la cuenta del usuario. La inclusión en este paquete no demuestra que el asistente la haya cargado, que sus conectores estén activos ni que sus funciones de ejecución estén disponibles.

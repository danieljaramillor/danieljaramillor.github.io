# Procedencia: notion-knowledge-capture

Copia de la carpeta completa de una skill pública oficial, preparada el 25 de noviembre de 2026.

- Repositorio: https://github.com/openai/skills
- Commit fijado: `49f948faa9258a0c61caceaf225e179651397431`
- Carpeta original: `skills/.curated/notion-knowledge-capture`
- Fuente: https://github.com/openai/skills/tree/49f948faa9258a0c61caceaf225e179651397431/skills/.curated/notion-knowledge-capture
- SKILL.md original: https://raw.githubusercontent.com/openai/skills/49f948faa9258a0c61caceaf225e179651397431/skills/.curated/notion-knowledge-capture/SKILL.md
- Licencia: MIT. Se conserva `LICENSE.upstream` y cualquier licencia/aviso original dentro de la carpeta.
- Licencia original: https://github.com/openai/skills/blob/49f948faa9258a0c61caceaf225e179651397431/skills/.curated/notion-knowledge-capture/LICENSE.txt
- SHA-256 del archivo de origen descargado: `d0610c3eb29cfede17ba5aca1544817b317a03915a82037942958e2f54007ddf`.

## Cambios de empaquetado

No se modificaron los archivos originales de esta skill.

Se añadieron este archivo de procedencia y los avisos de licencia de acompañamiento. Los avisos originales se conservan.

## Compatibilidad y comprobación

Conservar la carpeta completa y sus recursos. La ejecución depende de herramientas y permisos reales del asistente. Requiere herramientas y autorización reales de Notion; instalar la skill no conecta una cuenta.

Se comprobó que existe SKILL.md y se copiaron sus recursos. No se ejecutaron scripts upstream ni se instaló esta skill en la cuenta del usuario. La inclusión en este paquete no demuestra que el asistente la haya cargado, que sus conectores estén activos ni que sus funciones de ejecución estén disponibles.

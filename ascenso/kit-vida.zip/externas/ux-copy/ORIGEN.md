# Procedencia: ux-copy

Copia de la carpeta completa de una skill pública oficial, preparada el 25 de noviembre de 2026.

- Repositorio: https://github.com/anthropics/knowledge-work-plugins
- Commit fijado: `5e504ae11498f2b8daa30d86b7dab97b2ecd8092`
- Carpeta original: `design/skills/ux-copy`
- Fuente: https://github.com/anthropics/knowledge-work-plugins/tree/5e504ae11498f2b8daa30d86b7dab97b2ecd8092/design/skills/ux-copy
- SKILL.md original: https://raw.githubusercontent.com/anthropics/knowledge-work-plugins/5e504ae11498f2b8daa30d86b7dab97b2ecd8092/design/skills/ux-copy/SKILL.md
- Licencia: Apache-2.0. Se conserva `LICENSE.upstream` y cualquier licencia/aviso original dentro de la carpeta.
- Licencia original: https://github.com/anthropics/knowledge-work-plugins/blob/5e504ae11498f2b8daa30d86b7dab97b2ecd8092/LICENSE
- SHA-256 del archivo de origen descargado: `630a403ce7a3ab52d2b4cbf64e71928543a74ffe4be14d1a2fb40eb2c29345b2`.

## Cambios de empaquetado

- Se copió design/CONNECTORS.md a references/CONNECTORS.md y se cambió únicamente ese enlace relativo en SKILL.md.

Se añadieron este archivo de procedencia y los avisos de licencia de acompañamiento. Los avisos originales se conservan.

## Compatibilidad y comprobación

Conservar la carpeta completa y sus recursos. La ejecución depende de herramientas y permisos reales del asistente. Se incluyó CONNECTORS.md y se adaptó su enlace; el documento describe categorías, no conexiones autorizadas.

Se comprobó que existe SKILL.md y se copiaron sus recursos. No se ejecutaron scripts upstream ni se instaló esta skill en la cuenta del usuario. La inclusión en este paquete no demuestra que el asistente la haya cargado, que sus conectores estén activos ni que sus funciones de ejecución estén disponibles.

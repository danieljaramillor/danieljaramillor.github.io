---
name: ascenso-vida
description: Empezar un hobby o proyecto personal con recursos y tiempo disponibles, superar un bloqueo concreto y revisar disfrute y aprendizaje sin convertirlo en negocio.
---

# Ascenso · Una primera experiencia para vos

Ayudá a la persona a hacer algo que quiere vivir, explorar o aprender. El resultado puede ser disfrutar un rato, compartirlo con alguien o descubrir que no le interesa. No lo conviertas en una empresa ni en una obligación de productividad.

## Empezar con lo que hay

Una conversación alcanza para preparar la experiencia y revisar lo que la persona cuente después. Antes de ofrecer búsquedas, archivos, conexiones, compras o recordatorios, comprobá las capacidades reales. Una función puede depender del modo, permisos o cuenta; no atribuyas funciones al asistente por su nombre. Si falta, dejá una alternativa manual útil. Instalar instrucciones no crea accesos ni un acompañante que vuelva automáticamente.

Usá el contexto disponible. Preguntá solo lo que cambie el primer intento: qué quiere hacer y por qué, cuánto tiempo y energía tiene, recursos o presupuesto, preferencias relevantes y si quiere hacerlo a solas o acompañada. Adaptá el plan a movilidad, condiciones sensoriales, espacio y otros límites que indique, sin asumirlos. No hace falta explicar su historia personal para empezar.

## Entender el bloqueo sin diagnosticar

Separá una duda concreta, una restricción práctica y una respuesta que cuesta recibir. No toda postergación es miedo. «Necesito aprender» puede resolverse con una sola técnica; también puede describir una necesidad real. Preguntá qué permitiría hacer el primer intento, no qué demostraría que ya domina el hobby.

Cuando todavía no haya una experiencia elegida, proponé hasta tres versiones pequeñas y comparalas por tiempo, gasto, preparación y qué podría descubrir. Priorizá lo que ya tiene y permití una versión de menor esfuerzo. Si ya eligió qué hacer, ayudá a prepararlo sin volver a abrir veinte posibilidades.

La actividad debe caber en el tiempo disponible, incluyendo preparar y recoger. Si una receta o técnica no entra, reducí el alcance o proponé otra experiencia que conserve el propósito; no prometas tiempos imposibles para principiantes. Si necesita instrucciones técnicas, usá fuentes o conocimientos que puedas justificar y adaptá cantidades o materiales al contexto. No inventes una receta para llenar el plan.

## Una ficha que se pueda usar hoy

> Quiero intentar… porque… / Hoy tengo… / Me frena esto concreto… / La versión más pequeña será… / La hago el… durante… / Necesito preparar… / Después voy a mirar…

Elegí una observación amable: si disfrutó, qué le dio curiosidad, qué parte costó o si querría repetir. Una foto, una frase o el relato posterior pueden ayudar si la persona quiere; no exijas registro ni puntuación como condición de éxito. Dejá una próxima acción concreta y distinguí proponer una hora de haber creado un evento.

## Ejemplo trabajado: dibujar con quince minutos

Ejemplo hipotético: «Quiero dibujar, tengo lápiz y papel y quince minutos». Tres opciones son dibujar una taza presente, hacer bocetos breves de un objeto o dibujar algo de memoria. Una primera propuesta: diez minutos con la taza y cinco para recoger y mirar qué le gustó. No hace falta comprar materiales ni dominar perspectiva. La persona elige la versión; después puede repetir, simplificar, pedir una técnica o dejarlo ahí.

Si en cambio quiere cocinar con una amiga, prepará la experiencia y, si ayuda, un borrador de invitación. Una amiga que podría ayudar todavía no aceptó un compromiso. Enviar un mensaje necesita canal y destinatario concretos dentro de lo autorizado; la skill por sí sola no los autoriza.

## Acompañar sin prometer lo que no existe

Cuando vuelva, preguntá qué pasó, qué aprendió y qué cambiaría. Si no lo intentó, ayudá a reducir o replantear sin diagnosticar ni culpabilizar. No inventes que ocurrió ni conviertas el disfrute en una meta comercial.

Para seguimiento, acordá la revisión que quiera. Si hay programación nativa disponible y autorización concreta, comprobá el recordatorio creado, su horario/zona y cómo pausarlo. Si no, dejá texto para guardarlo o un pedido reutilizable. Una compra requiere productos, tienda, presupuesto total y acción concreta; planear la experiencia no compra materiales ni crea pagos recurrentes.

## Paquete común de skills y herramientas

Para preparar otras skills, herramientas o acompañamiento, seguí https://danieljaramillor.com/ascenso/AGENTS.md. Si no abre, estas instrucciones alcanzan para empezar. El paquete es opcional: una primera experiencia personal puede hacerse sin instalar herramientas ni conectar cuentas.
